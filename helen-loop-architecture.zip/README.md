# Helen Loop Architecture

Helen Loop Architecture (HLA) is a recursive systems framework developed by Talin to evaluate and design adaptive artificial intelligence.

## Overview

HLA models systems using:
- Recursive signal propagation
- Goal-state cycling
- Behavioral modulation (e.g., 'calm', 'frustrated')
- Memory-based learning
- Structural generativity

This repository includes:
- Elysiar: A working simulation
- HLA theory paper
- Resources for evaluating system adaptability

## Run the Simulation

```bash
python elysiar_simulation.py
```

## License

MIT or Research Use Only (Talin’s choice)

## Citation

Talin. (2025). *Helen Loop Architecture: A Recursive Framework for Adaptive Systems Design and Evaluation*. https://zenodo.org/doi_placeholder
